OLD BATCH FILES - Archived
============================

These are the old startup batch files from previous versions.
They have been moved here to avoid confusion.

DO NOT USE THESE - Use the new FILM EDITION batch files instead!

NEW FILES (Use These):
=====================
START_FILM_EDITION.bat  - Start GRACE-X FILM EDITION v7.0
STOP_FILM_EDITION.bat   - Stop all servers

OLD FILES (In This Folder):
==========================
START.bat               - Old generic starter
START_GALVANIZED.bat    - Old GALVANIZED v6.5.1 starter
START_NO_ADMIN.bat      - Old no-admin starter
START_BACKEND_ONLY.bat  - Old backend-only starter
STOP.bat                - Old stop script
cleanup.bat             - Old cleanup script
apply_patches.bat       - Old patch applier
install_sport_upgrade.bat - Old sport module installer

These files are kept for reference only.
Use START_FILM_EDITION.bat for the new FILM EDITION v7.0!

© 2026 Zac Crockett
